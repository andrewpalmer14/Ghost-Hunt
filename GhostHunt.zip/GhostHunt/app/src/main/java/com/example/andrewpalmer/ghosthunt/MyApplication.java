package com.example.andrewpalmer.ghosthunt;

import android.app.Application;

public class MyApplication extends Application {
    private boolean[] ghostsLocked = {true, true, true, true, true, true, true, true, true, true, true, true};

    public boolean[] getGhostsLocked() {
        return this.ghostsLocked;
    }

    public void setGhostsLocked(boolean[] ghostsLocked) {
        this.ghostsLocked = ghostsLocked;
    }
}
