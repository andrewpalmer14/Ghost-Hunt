package com.example.andrewpalmer.ghosthunt;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

public class RowItem {

    private String ghost_name;
    private int profile_pic_id;
    private String status;
    private String contact_type;

    public RowItem(String ghost_name, int profile_pic_id, String status, String contact_type) {
        this.ghost_name = ghost_name;
        this.profile_pic_id = profile_pic_id;
        this.status = status;
        this.contact_type = contact_type;
    }

    public String getGhostName() {
        return ghost_name;
    }

    public void getGhostName(String member_name) {
        this.ghost_name = member_name;
    }

    public int getProfilePicId() {
        return profile_pic_id;
    }

    public void setProfile_pic_id(int profile_pic_id) {
        this.profile_pic_id = profile_pic_id;
    }

    public String getGhostStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContactType() {
        return contact_type;
    }

    public void setContactType(String contactType) {
        this.contact_type = contactType;
    }

}
