/*
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.andrewpalmer.ghosthunt.augmentedimage;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.andrewpalmer.ghosthunt.HomeFragment;
import com.example.andrewpalmer.ghosthunt.MapFragment;
import com.example.andrewpalmer.ghosthunt.R;
import com.example.andrewpalmer.ghosthunt.helpers.SnackbarHelper;
import com.google.ar.core.Anchor;
import com.google.ar.core.AugmentedImage;
import com.google.ar.core.Frame;
import com.google.ar.core.TrackingState;
import com.google.ar.sceneform.AnchorNode;
import com.google.ar.sceneform.FrameTime;
import com.google.ar.sceneform.math.Quaternion;
import com.google.ar.sceneform.math.Vector3;
import com.google.ar.sceneform.rendering.ModelRenderable;
import com.google.ar.sceneform.ux.ArFragment;
import com.google.ar.sceneform.ux.TransformableNode;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * This application demonstrates using augmented images to place anchor nodes. app to include image
 * tracking functionality.
 */
public class AugmentedImageActivity extends AppCompatActivity {

  private ArFragment arFragment;
  private ImageView fitToScanView;
  private ModelRenderable myRenderable;


  // Augmented image and its associated center pose anchor, keyed by the augmented image in
  // the database.
  private final Map<AugmentedImage, AugmentedImageNode> augmentedImageMap = new HashMap<>();

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    System.out.println("onnCreate called!");
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_augmented_image);



    /*
    setOnClickListener(new View.OnClickListener() {
      public void onClick(View v) {
        openMapPage();
      }
    });
     */

    arFragment = (ArFragment) getSupportFragmentManager().findFragmentById(R.id.ux_fragment);
    fitToScanView = findViewById(R.id.image_view_fit_to_scan);

    ModelRenderable.builder()
            .setSource(this, Uri.parse("Animated Human.sfb"))
            .build()
            .thenAccept(renderable -> myRenderable = renderable)
            .exceptionally(
                    throwable -> {
                      Toast toast =
                              Toast.makeText(this, "Unable to load andy renderable", Toast.LENGTH_LONG);
                      toast.setGravity(Gravity.CENTER, 0, 0);
                      toast.show();
                      return null;
                    });
    arFragment.getArSceneView().getScene().addOnUpdateListener(this::onUpdateFrame);
  }

  private void backPressed() {
    System.out.println("back pressed");
  }

  @Override
  public void onBackPressed() {
    System.out.println("onnBackPressed called!");
    super.onBackPressed();

  }

  @Override
  protected void onResume() {
    System.out.println("onnResume called!");
    super.onResume();
    if (augmentedImageMap.isEmpty()) {
      fitToScanView.setVisibility(View.VISIBLE);
    }
  }

  @Override
  protected void onStart() {
    System.out.println("onnStart called!");
    super.onStart();
  }

  /**
   * Registered with the Sceneform Scene object, this method is called at the start of each frame.
   *
   * @param frameTime - time since last frame.
   */
  private void onUpdateFrame(FrameTime frameTime) {
    Frame frame = arFragment.getArSceneView().getArFrame();

    // If there is no frame or ARCore is not tracking yet, just return.
    if (frame == null || frame.getCamera().getTrackingState() != TrackingState.TRACKING) {
      return;
    }

    Collection<AugmentedImage> updatedAugmentedImages =
        frame.getUpdatedTrackables(AugmentedImage.class);
    for (AugmentedImage augmentedImage : updatedAugmentedImages) {
      switch (augmentedImage.getTrackingState()) {
        case PAUSED:
          // When an image is in PAUSED state, but the camera is not PAUSED, it has been detected,
          // but not yet tracked.
          //String text = "Detected Image " + augmentedImage.getIndex();
          //SnackbarHelper.getInstance().showMessage(this, text);
          break;

        case TRACKING:
          // Have to switch to UI Thread to update View.
          fitToScanView.setVisibility(View.GONE);
          // Create a new anchor for newly found images.
          if (!augmentedImageMap.containsKey(augmentedImage)) {
            if (augmentedImage.getName().equalsIgnoreCase("bsu.jpg")) {
              Anchor anchor = augmentedImage.createAnchor(augmentedImage.getCenterPose());
              AnchorNode anchorNode = new AnchorNode(anchor);
              anchorNode.setParent(arFragment.getArSceneView().getScene());

              TransformableNode myAsset = new TransformableNode(arFragment.getTransformationSystem());
              //myAsset.setLocalRotation(Quaternion.axisAngle(Vector3.forward(), 90f));
              //myAsset.setLocalPosition(new Vector3(0f, -5f, 5f));
              myAsset.setLocalPosition(new Vector3(0f, 0.1f, 1f));
              //                                      x       y        z
              //y=extending out of picture(pos = away from wall, neg = into wall)
              //z=vertical, (pos = down, neg = up)
              System.out.println("object local position: " + myAsset.getLocalPosition());
              myAsset.setLocalRotation(Quaternion.axisAngle(Vector3.left(), 90f));
              //myAsset.getLocalRotation().set(Quaternion.axisAngle(new Vector3(91.0f, 91.0f, 91.0f), 90f)); //.set(0f, 0f, 0f, 0f);
              myAsset.setParent(anchorNode);
              myAsset.setRenderable(myRenderable);
              myAsset.select();
            } else if (augmentedImage.getName().equalsIgnoreCase("default.jpg")) {
              AugmentedImageNode node = new AugmentedImageNode(this);
              node.setImage(augmentedImage);
              augmentedImageMap.put(augmentedImage, node);
              arFragment.getArSceneView().getScene().addChild(node);
            }
          }
          break;

        case STOPPED:
          augmentedImageMap.remove(augmentedImage);
          break;
      }
    }
  }
}
