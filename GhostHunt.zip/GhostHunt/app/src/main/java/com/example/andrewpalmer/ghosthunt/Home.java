package com.example.andrewpalmer.ghosthunt;

import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.design.widget.BottomNavigationView;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.andrewpalmer.ghosthunt.augmentedimage.AugmentedImageActivity;
import com.example.andrewpalmer.ghosthunt.augmentedimage.AugmentedImageNode;
import com.example.andrewpalmer.ghosthunt.helpers.SnackbarHelper;
import com.google.ar.core.Anchor;
import com.google.ar.core.AugmentedImage;
import com.google.ar.core.Frame;
import com.google.ar.core.TrackingState;
import com.google.ar.sceneform.AnchorNode;
import com.google.ar.sceneform.FrameTime;
import com.google.ar.sceneform.rendering.ModelRenderable;
import com.google.ar.sceneform.ux.ArFragment;
import com.google.ar.sceneform.ux.TransformableNode;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Home extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private Fragment fragment = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        System.out.println("onnHomeCreateCalled!");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);
        fragment = new MapFragment();
        loadFragment(fragment);
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
            return true;
        }
        return false;
    }

    @Override
    protected void onStart() {
        System.out.println("onnHomeStartCalled!");
        super.onStart();
    }

    @Override
    protected void onResume() {
        System.out.println("onnHomeResumeCalled!");
        super.onResume();
        fragment = new MapFragment();
        //((MapFragment) fragment).ghostsLocked = ghostsLocked;
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.navigation_map);
        loadFragment(fragment);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        //fragment = null;

        switch(item.getItemId()) {
            case R.id.navigation_home:
                //Intent intent = new Intent(Home.this, AugmentedImageActivity.class);
                //startActivity(intent);
                if (fragment.getClass() != HomeFragment.class) {
                    fragment = new HomeFragment();
                    //((HomeFragment) fragment).ghostsLocked = ghostsLocked;

                }
                break;

            case R.id.navigation_map:
                if (fragment.getClass() != MapFragment.class) {
                    fragment = new MapFragment();
                }
                break;

            case R.id.navigation_ghosts:
                if (fragment.getClass() != GhostsFragment.class) {
                    fragment = new GhostsFragment();
                }
                break;
        }

        return loadFragment(fragment);
    }

}
