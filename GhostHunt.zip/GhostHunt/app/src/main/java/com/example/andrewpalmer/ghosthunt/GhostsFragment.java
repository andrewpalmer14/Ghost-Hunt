package com.example.andrewpalmer.ghosthunt;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class GhostsFragment extends Fragment implements AdapterView.OnItemClickListener {

    String[] ghost_names;
    TypedArray profile_pics;
    String[] statues;
    String[] contactType;

    List<RowItem> rowItems;
    AbsListView mylistview;
    CustomAdapter adapter;

    private boolean listCreated = false;

    View v;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_ghosts, null);

            rowItems = new ArrayList<RowItem>();

            ghost_names = getResources().getStringArray(R.array.Ghost_names);

            profile_pics = getResources().obtainTypedArray(R.array.Profile_pics);

            statues = getResources().getStringArray(R.array.Statuses);

            contactType = getResources().getStringArray(R.array.ContactType);


            for (int i = 0; i < ghost_names.length; i++) {
                System.out.println(i);
                System.out.println("ghost name: " + ghost_names[i]);
                RowItem item = new RowItem(ghost_names[i],
                        profile_pics.getResourceId(i, -1),
                        statues[i],
                        contactType[i]);
                rowItems.add(item);
            }

            mylistview = (AbsListView) v.findViewById(R.id.list_view);
            adapter = new CustomAdapter(getContext(), rowItems);
            mylistview.setAdapter(adapter);

            mylistview.setOnItemClickListener(this);


        return v;
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position,
                            long id) {

        String member_name = rowItems.get(position).getGhostName();
        Toast.makeText(v.getContext().getApplicationContext(), "" + member_name,
                Toast.LENGTH_SHORT).show();
    }
}
